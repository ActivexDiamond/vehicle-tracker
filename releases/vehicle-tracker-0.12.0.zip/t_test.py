#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 17 06:00:04 2023
@license: MIT

@author: Dulfiqar 'activexdiamond' H. Al-Safi
"""
"""
############################## Dependencies ##############################
from twilio.rest import Client

############################## Custom Modules ##############################
import config

############################## Twilio ##############################
client = Client(config.TWILIO_SID, config.TWILIO_AUTH_TOKEN)

def sendViolation(body):
    if not config.SEND_SMS: 
        print(f"Messaging disabled. Fake text={body}")    
        return False
    for num in config.TARGET_PHONE_NUMBERS:
        msg = client.messages.create(body=body, to=num,
                from_=config.SENDER_PHONE_NUMBER)
        print(f"Sent SMS! receiver={num}\tSID={msg.sid}\tText={body}")
    return True

#print(sendViolation("hey"))

############################## String Distance ##############################
import difflib
import Levenshtein

ARABIC_WORD_LIST = [
"بغداد",
"البصرة",
"ذي قار",
"المثنى",
"نينوى ",
"بابل",
"ديالى",
"الانبار",
"القادسية",
"ميسان",
"صلاح الدين",
"كربلاء",
"النجف",
"كركوك",
"دهوك",
"اربيل",
"السليمانية",
"واسط",
"حلبجة",
"اجرة",
"خصوصي",
"حمل",
"حكومية",
]

texts = [
"بعداد",
"السبيملنية",
"واشط",
"كيسات",
"خليجة",
"ايتييت",
]

MAX_DIFF = 3

a = "بعداد"

b = [
"بغداد",
"البصرة",
"ذي قار",
]
"""
#for valid in b:
#    diff = difflib.ndiff(a, valid)
#    for x in diff: print(x)
#    print("==========")
"""
for text in texts:
    closest = 1000
    closestText = ""
    for valid in ARABIC_WORD_LIST:
        distance = Levenshtein.distance(text, valid)
        if distance < closest:
            closest = distance 
            closestText = valid
    
    print(f"text={text}, closest= {closest} / {closestText}")
    s = "Unknown" if closest > MAX_DIFF else closestText
    print(s)
        
    #print('{} => {}'.format(a,b))  
    #for i,s in enumerate(difflib.ndiff(a, b)):
    #    if s[0]==' ': continue
    #    elif s[0]=='-':
    #        print(u'Delete "{}" from position {}'.format(s[-1],i))
    #    elif s[0]=='+':
    #        print(u'Add "{}" to position {}'.format(s[-1],i))    
    #print() 
"""
class Foo:
    def __init__(self, ID):
        self.id = ID
        
a = Foo(1)
a2 = Foo(1)

b = Foo(2)
b2 = Foo(2)

c = Foo(3)
d = Foo(4)
cars = [d, a, b, c, a2, a, b2, b, a]

#If car has no matching objects, remove it from the list.
removals = []
for i, c in enumerate(cars):
    for j in range(i + 1, len(cars)):
        c2 = cars[j]
        if c == c2: continue
        if any(j == item for item in removals): continue
        if c.id == c2.id:
            removals.append(j)
for c in cars: print(c.id)
print("====")
removals.sort()
for i in range(len(removals) - 1, -1, -1):
    print(removals[i])
    del cars[removals[i]]
print("====")
for c in cars: print(c.id)
