#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 22:03:49 2023
@license: MIT

@author: Dulfiqar 'activexdiamond' H. Al-Safi
"""

############################## Dependencies ##############################

############################## Custom Modules ##############################
import config

############################## Car Class ##############################
class Car:
    INVALID_STATE = {}
    def __init__(self, bbox):
        self.startTime = -1
        self.endTime = -1
        self.bbox = bbox

############################## Setters ##############################        
    def setStartTime(self, t):
        if self.startTime == -1: return
        self.startTime = t

    def setEndTime(self, t):
        self.endTime = t
        
    def setBbox(self, bbox):
        self.bbox = bbox
        
############################## Getters ##############################        
    def isComplete(self):
        return self.startTime != -1 and self.endTime != -1
    
    def getTime(self):
        if not self.isComplete(self):
            self.INVALID_STATE
        return self.endTime - self.startTime
    
    def getSpeed(self):
        if not self.isComplete(self):
            self.INVALID_STATE
        return config.LINES_DISTANCE / self.getSpeed(self)
            
    def getBbox(self):
        return self.bbox
    
    def getCenter(self):
        x, y, w, h = self.bbox
        return (x * 2 + w) // 2, (y * 2 + h) // 2