#!/usr/bin/env python3
# -*- coding: utf-8 -*-
TWILIO_SID = "AC97dd760a27c23aa3e00ef479afba686d"
TWILIO_AUTH_TOKEN = "46a634aad2b7825f06a89562eaa945f4"