#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 22:03:49 2023
@license: MIT

@author: Dulfiqar 'activexdiamond' H. Al-Safi
"""

############################## Dependencies ##############################
#Native
import math
import time
import os

#Image Manipulation
import cv2

#Math Libs
import numpy 

############################## Custom Modules ##############################
import config
############################## Core API ##############################
